export type MessageFromVScode = "connected"  |
  "VScode here" | "code";


export type MessageFromWebView = "connected" | 
  "WebView here";