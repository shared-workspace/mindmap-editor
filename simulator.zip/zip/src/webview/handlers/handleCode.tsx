// import React from "react";
// import Tokenizr from "tokenizr";
// const Praser = {
//     Preprocesser: /#include/,
// }
// let lexer = new Tokenizr();
// lexer.rule(Praser.Preprocesser, (ctx, match)=>{

// })
// export default function handleCode(code: string){

// }